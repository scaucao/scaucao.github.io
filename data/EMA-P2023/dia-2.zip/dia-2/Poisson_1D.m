function Poisson_1D(m)

format long;

%Este programa resuelve el problema: -u''=f en I=(0,1),
%con condiciones de contorno tipo Dirichlet: u(0) = u(1) = 0,
%utilizando el metodo de elementos finitos

%DECLARACION DE VARIABLES
% n  = numero de nodos interiores del intervalo I=(0,1)
% hx = paso uniforme del intervalo I=(0,1)
% X  = coordenada x del i-esimo nodo
% ue = valor de la solucion exacta en el i-esimo nodo
% ua = valor de la solucion aproximada en el i-esimo nodo
% fc = vector de carga

%Comenzamos cargando la funcion exacta y dato f:
ue  =@(x) -exp(-x) + exp(-(x.*x));
due =@(x)  exp(-x) - 2*x.*exp(-(x.*x));
fun =@(x) -(4*x.*x*exp(-(x.*x)) - 2*exp(-(x.*x)) - exp(-x));

for k=1:m
%Iniciamos el espaciado uniforme del intervalo I=(0,1)
    n  = 2^k+1;
    X  = linspace(0,1,n+2);
    hx(k) = 1/(n+1);
    DoF(k) = n;

%Calculamos la matriz de rigidez
    A = spdiags([-(1/hx(k))*ones(n,1) (2/hx(k))*ones(n,1) -(1/hx(k))*ones(n,1)], -1:1, n, n);

%Calculamos el vector de carga
    fc = sparse(n,1);
    l  = (sqrt(3)-1) / (2*sqrt(3));  

    for i=2:n+1
        fc(i-1) = (hx(k)/2)*( (fun(X(i-1) + l*hx(k)) + fun(X(i+1) - l*hx(k)))*l ...
                   + (fun(X(i) - l*hx(k)) + fun(X(i) + l*hx(k)))*(1 - l) );
    end

%Resolvemos el sistema lineal
    uh = A\fc;

%Imponemos condiciones de contorno
    ua = [0;uh;0];

%Calculo de error y tasa de convergencia    
    for i=1:n+1
        auxL2(i) = (hx(k)/6)*( abs(ue(X(i)) - ua(i))^2 ... 
                    + 4*abs(ue((X(i) + X(i+1))/2) - (ua(i) + ua(i+1))/2)^2 ...
                    + abs(ue(X(i+1)) - ua(i+1))^2 );

        dua = (ua(i+1) - ua(i)) / hx(k); 
        auxH1(i) = (hx(k)/6)*( abs(due(X(i)) - dua)^2 ...
                    + 4*abs(due((X(i) + X(i+1))/2) - (dua + dua)/2)^2 ...
                    + abs(due(X(i+1)) - dua)^2 );
    end
    errorL2(k) = sqrt(sum(auxL2));
    errorH1(k) = sqrt(sum(auxL2) + sum(auxH1));

    if (k > 1)
        rateL2(k) = log(errorL2(k)/errorL2(k-1)) / log(hx(k)/hx(k-1));
        rateH1(k) = log(errorH1(k)/errorH1(k-1)) / log(hx(k)/hx(k-1));
    end
end

[hx' errorL2' rateL2' errorH1' rateH1']

%Solucion exacta evaluada en el i-esimo nodo
XX = 0:0.01:1;
ue = ue(XX);

%Grafico de la solucion exacta vs aproximada
figure(1);
plot(XX,ue,'b',X,ua,'k')
grid on
title('Solucion Exacta v/s Aproximada')
ylabel('u(x) y u_{h}(x)')
xlabel('x')
legend('u(x)','u_{h}(x)')

%Grafico loglog DoF vs error
figure(2);
loglog(DoF,errorL2,'b', DoF,errorH1,'r')
grid on
title('Orden de convergencia DoF / Errores')
ylabel('||u - uh||')
xlabel('DoF')
legend('eL2','eH1')

%Grafico loglog H vs error
figure(3);
loglog(hx,errorL2,'b', hx,errorH1,'r')
grid on
title('Orden de convergencia H / Errores')
ylabel('||u - uh||')
xlabel('Tama~no de malla h')
legend('eL2','eH1')
